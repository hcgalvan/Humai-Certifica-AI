# Pose_Estimation
This is AI personal trainer demo. İt detects squat exercise and counts it for sportsman. I use mediapipe library to detect the key points of human.


![WhatsApp Image 2021-09-01 at 23 56 55](https://user-images.githubusercontent.com/74606830/131746599-262cb5f7-a9a0-4efe-9d3c-2259df7af30c.jpeg)

