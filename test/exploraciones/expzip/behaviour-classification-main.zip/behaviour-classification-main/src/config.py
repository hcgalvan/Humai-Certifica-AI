# Generate data configuration
N_FRAME = 600
N_DELAY = 10

# Train data configuration
N_EPOCH = 32
BATCH_SIZE = 64
N_TIME = 10