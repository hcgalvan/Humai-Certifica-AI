def test_renderer() -> None:
    assert True
