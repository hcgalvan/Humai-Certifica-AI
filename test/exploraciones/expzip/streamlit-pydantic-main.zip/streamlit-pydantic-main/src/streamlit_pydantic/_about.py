"""Information about this library. This file will automatically changed."""

__version__ = "0.6.0.dev1"
# __author__
# __email__
