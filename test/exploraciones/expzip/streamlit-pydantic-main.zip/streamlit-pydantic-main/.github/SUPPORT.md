# Support

Please refer to our [support](../../../#support--feedback) and [contribution](../../../#contribution) sections on our main README for more information.
