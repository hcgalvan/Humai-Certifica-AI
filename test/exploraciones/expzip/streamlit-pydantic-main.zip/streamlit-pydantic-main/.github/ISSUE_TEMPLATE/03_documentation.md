---
name: "📝 Documentation"
about: Is there a mistake in the docs, is anything unclear or do you have a suggestion?
title: ''
labels: documentation
assignees: ''

---

**Describe your request:**

<!-- Describe the problem or suggestion here. If you've found a mistake and you know the answer, feel free to submit a pull request straight away. -->

**Which page or section is this issue related to?**

<!-- Please include the URL. -->
