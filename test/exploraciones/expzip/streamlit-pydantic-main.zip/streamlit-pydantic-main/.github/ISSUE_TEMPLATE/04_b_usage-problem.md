---
name: "🧑‍💻 Usage Problem"
about: Do you have problems with usage and none of the suggestions in the docs helped?
title: ''
labels: 'support'
assignees: ''

---

<!--
Before opening a new issue, please make sure that we do not have any duplicates already open. You can ensure this by searching the issue list for this repository. If there is a duplicate, please close your issue and add a comment to the existing issue instead. Also, be sure to check our documentation first.
-->

**Describe the issue:**

<!-- Describe your issue, but please be descriptive! Include screenshots, logs, code or other info to help explain your problem -->

**Technical details:**

- Host Machine OS (Windows/Linux/Mac):
